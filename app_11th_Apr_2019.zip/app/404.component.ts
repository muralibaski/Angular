import { Component } from '@angular/core';

@Component({
template:`
<h1><b> 404 Error</b> </h1>
`,
styles:[
    `
    h1{color:red}
    `
]
})
export class Error404Component{
}