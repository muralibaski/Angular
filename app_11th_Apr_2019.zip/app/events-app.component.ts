import { Component } from '@angular/core';

@Component({
  selector: 'app-events',
  //template:``,
  styles: ["div {color:yellow}"],
  templateUrl: './events-app.component.html',
//  styleUrls: ['./app.component.css']
})
export class EventsAppComponent {
 
  }
 
console.log("Hello");