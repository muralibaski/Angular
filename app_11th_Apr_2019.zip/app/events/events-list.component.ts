import { Component, OnInit } from '@angular/core';
import { EventService } from './shared/event.service';

@Component({
  providers:[EventService],
  selector: 'events-list',
  template:`<div> 
  <h1><b> Upcoming Angular Events...!!! </b></h1> <hr>
  <div class="row">
  <div *ngFor="let oneEvent of events" class="col-md-5">
  
  <events-thumbnail [event]= "oneEvent" ></events-thumbnail></div></div>  
  `,
//  styleUrls: ['./events.component.css']
})

export class EventsListComponent implements OnInit {
  title='conference-prj';

  events:any[]; //how do we get all the event details here?
  //eventService:EventService = new EventService();

  constructor(private eventService:EventService) {
   console.log("Inside Constructor:");
    // this.events = this.eventService.getEvents();
   }
   ngOnInit() {
     this.events= this.eventService.getEvents();
     console.log("Inside OnInit Method:")
  }
  
}