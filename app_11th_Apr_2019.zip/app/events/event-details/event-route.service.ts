import {Injectable} from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, Router } from '@angular/router';
import { EventService } from '../shared/event.service';
@Injectable()
export class EventRouteActivator implements CanActivate{
constructor(private eventService:EventService, private router:Router)
{

}
//return type of this method is always boolean
canActivate(route:ActivatedRouteSnapshot)
{
    console.log("String Value --> "+route.params['id']);
    console.log("Interger Value --> "+route.params['id']);
    console.log("EventObject Value --> "+this.eventService.getEvent(+route.params['id']));
    console.log("EventObject404 Page --> "+!this.eventService.getEvent(+route.params['id']));
    console.log("EventDetailsComponent Value --> "+!!this.eventService.getEvent(+route.params['id']));
    const eventObjectExists = !!this.eventService.getEvent(+route.params['id']);
    if(!eventObjectExists)
    {
        this.router.navigateByUrl("/404");
    }
    return eventObjectExists;
}
}